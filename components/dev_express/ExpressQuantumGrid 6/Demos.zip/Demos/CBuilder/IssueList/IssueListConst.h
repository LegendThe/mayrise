//---------------------------------------------------------------------------

#ifndef IssueListConstH
#define IssueListConstH
//---------------------------------------------------------------------------
#endif

const ProjectsFrameID  = 1;
const ItemsFrameID = 2;
const DepartmentsFrameID = 3;
const UsersFrameID = 4;
const TeamsFrameID  = 5;
const ScheduleFrameID = 6;
