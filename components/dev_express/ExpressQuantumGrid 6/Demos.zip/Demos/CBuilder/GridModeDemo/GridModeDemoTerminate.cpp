//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "GridModeDemoTerminate.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TGridModeDemoTerminateForm *GridModeDemoTerminateForm;
//---------------------------------------------------------------------------
__fastcall TGridModeDemoTerminateForm::TGridModeDemoTerminateForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
