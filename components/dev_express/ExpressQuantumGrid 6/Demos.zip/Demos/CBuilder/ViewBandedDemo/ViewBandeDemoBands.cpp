//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ViewBandeDemoBands.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxListBox"
#pragma resource "*.dfm"
TViewBandeDemoBandsForm *ViewBandeDemoBandsForm;
//---------------------------------------------------------------------------
__fastcall TViewBandeDemoBandsForm::TViewBandeDemoBandsForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
