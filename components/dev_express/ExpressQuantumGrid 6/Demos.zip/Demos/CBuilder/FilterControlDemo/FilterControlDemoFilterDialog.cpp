//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FilterControlDemoFilterDialog.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFilterControlDemoFilterDialogForm *FilterControlDemoFilterDialogForm;
//---------------------------------------------------------------------------
__fastcall TFilterControlDemoFilterDialogForm::TFilterControlDemoFilterDialogForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
