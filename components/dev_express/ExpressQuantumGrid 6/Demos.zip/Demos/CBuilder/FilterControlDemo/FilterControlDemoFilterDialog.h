//---------------------------------------------------------------------------

#ifndef FilterControlDemoFilterDialogH
#define FilterControlDemoFilterDialogH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFilterControlDemoFilterDialogForm : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
  __fastcall TFilterControlDemoFilterDialogForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFilterControlDemoFilterDialogForm *FilterControlDemoFilterDialogForm;
//---------------------------------------------------------------------------
#endif
