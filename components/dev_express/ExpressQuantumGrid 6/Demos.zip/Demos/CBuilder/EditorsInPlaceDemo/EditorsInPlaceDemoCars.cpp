//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EditorsInPlaceDemoCars.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxCheckBox"
#pragma link "cxContainer"
#pragma link "cxControls"
#pragma link "cxDBEdit"
#pragma link "cxEdit"
#pragma link "cxMemo"
#pragma link "cxTextEdit"
#pragma link "cxListBox"
#pragma resource "*.dfm"
TEditorsInPlaceDemoCarsForm *EditorsInPlaceDemoCarsForm;
//---------------------------------------------------------------------------
__fastcall TEditorsInPlaceDemoCarsForm::TEditorsInPlaceDemoCarsForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
 
