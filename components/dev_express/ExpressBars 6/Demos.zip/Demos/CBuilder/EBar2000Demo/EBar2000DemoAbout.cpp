//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "EBar2000DemoAbout.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TEBar2000DemoAboutForm *EBar2000DemoAboutForm;
//---------------------------------------------------------------------------
__fastcall TEBar2000DemoAboutForm::TEBar2000DemoAboutForm(TComponent* Owner)
  : TEBarsAboutForm(Owner)
{
}
//---------------------------------------------------------------------------
