//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SampleDockingRichText.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSampleDockingRichTextFrame *SampleDockingRichTextFrame;
//---------------------------------------------------------------------------
__fastcall TSampleDockingRichTextFrame::TSampleDockingRichTextFrame(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
