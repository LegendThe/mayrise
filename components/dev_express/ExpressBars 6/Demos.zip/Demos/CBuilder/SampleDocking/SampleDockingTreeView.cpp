//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SampleDockingTreeView.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSampleDockingTreeViewFrame *SampleDockingTreeViewFrame;
//---------------------------------------------------------------------------
__fastcall TSampleDockingTreeViewFrame::TSampleDockingTreeViewFrame(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
 
