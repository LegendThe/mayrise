//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "SampleDockingRadioGroup.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSampleDockingRadioGroupFrame *SampleDockingRadioGroupFrame;
//---------------------------------------------------------------------------
__fastcall TSampleDockingRadioGroupFrame::TSampleDockingRadioGroupFrame(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
