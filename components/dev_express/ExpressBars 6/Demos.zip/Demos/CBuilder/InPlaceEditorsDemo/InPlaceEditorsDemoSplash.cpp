//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "InPlaceEditorsDemoSplash.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TfrmLoading *frmLoading;
//---------------------------------------------------------------------------
__fastcall TfrmLoading::TfrmLoading(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


