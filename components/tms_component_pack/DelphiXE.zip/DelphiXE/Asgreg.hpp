// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ASGReg.pas' rev: 22.00

#ifndef AsgregHPP
#define AsgregHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <AdvGrid.hpp>	// Pascal unit
#include <BaseGrid.hpp>	// Pascal unit
#include <asgcheck.hpp>	// Pascal unit
#include <AsgMemo.hpp>	// Pascal unit
#include <AdvSpin.hpp>	// Pascal unit
#include <AsgReplaceDialog.hpp>	// Pascal unit
#include <AsgFindDialog.hpp>	// Pascal unit
#include <asgprev.hpp>	// Pascal unit
#include <asgprint.hpp>	// Pascal unit
#include <AsgHTML.hpp>	// Pascal unit
#include <frmctrllink.hpp>	// Pascal unit
#include <AdvGridCSVPager.hpp>	// Pascal unit
#include <AsgImport.hpp>	// Pascal unit
#include <AsgListb.hpp>	// Pascal unit
#include <AdvGridWorkbook.hpp>	// Pascal unit
#include <AdvGridLookupBar.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Asgreg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Asgreg */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Asgreg;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AsgregHPP
