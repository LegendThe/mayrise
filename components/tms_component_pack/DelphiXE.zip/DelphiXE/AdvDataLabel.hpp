// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvDataLabel.pas' rev: 22.00

#ifndef AdvdatalabelHPP
#define AdvdatalabelHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advdatalabel
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TDataType { dtString, dtInteger, dtFloat, dtDateTime };
#pragma option pop

#pragma option push -b-
enum TEllipsis { elNone, elEnd, elPath };
#pragma option pop

class DELPHICLASS TAdvCustomDataLabel;
class PASCALIMPLEMENTATION TAdvCustomDataLabel : public Controls::TGraphicControl
{
	typedef Controls::TGraphicControl inherited;
	
private:
	int FCaptionMargin;
	Classes::TAlignment FCaptionAlignment;
	Classes::TAlignment FDataAlignment;
	Graphics::TFont* FDataFont;
	int FDataIndent;
	TEllipsis FDataEllipsis;
	TEllipsis FCaptionEllipsis;
	System::UnicodeString FSeparator;
	bool FURLUnderline;
	Graphics::TColor FURLColor;
	void __fastcall SetCaptionMargin(const int Value);
	void __fastcall SetCaptionAlignment(const Classes::TAlignment Value);
	void __fastcall SetDataAlignment(const Classes::TAlignment Value);
	void __fastcall SetDataIndent(const int Value);
	void __fastcall SetDataFont(const Graphics::TFont* Value);
	void __fastcall SetCaptionEllipsis(const TEllipsis Value);
	void __fastcall SetDataEllipsis(const TEllipsis Value);
	void __fastcall SetSeparator(const System::UnicodeString Value);
	void __fastcall SetURLColor(const Graphics::TColor Value);
	void __fastcall SetURLUnderline(const bool Value);
	System::UnicodeString __fastcall GetVersion(void);
	void __fastcall SetVersion(const System::UnicodeString Value);
	int __fastcall GetVersionNr(void);
	
protected:
	void __fastcall DrawItem(System::UnicodeString Caption, System::UnicodeString Data, Graphics::TFont* DataFont, Classes::TAlignment AAlignment, TEllipsis AEllipsis, const Types::TRect &ARect, bool Selected);
	
public:
	__fastcall virtual TAdvCustomDataLabel(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvCustomDataLabel(void);
	__property Classes::TAlignment CaptionAlignment = {read=FCaptionAlignment, write=SetCaptionAlignment, default=0};
	__property TEllipsis CaptionEllipsis = {read=FCaptionEllipsis, write=SetCaptionEllipsis, default=0};
	__property int CaptionMargin = {read=FCaptionMargin, write=SetCaptionMargin, nodefault};
	__property Classes::TAlignment DataAlignment = {read=FDataAlignment, write=SetDataAlignment, default=0};
	__property TEllipsis DataEllipsis = {read=FDataEllipsis, write=SetDataEllipsis, default=0};
	__property Graphics::TFont* DataFont = {read=FDataFont, write=SetDataFont};
	__property int DataIndent = {read=FDataIndent, write=SetDataIndent, default=60};
	__property System::UnicodeString Separator = {read=FSeparator, write=SetSeparator};
	__property Graphics::TColor URLColor = {read=FURLColor, write=SetURLColor, default=16711680};
	__property bool URLUnderline = {read=FURLUnderline, write=SetURLUnderline, default=1};
	__property System::UnicodeString Version = {read=GetVersion, write=SetVersion};
};


class DELPHICLASS TAdvDataLabel;
class PASCALIMPLEMENTATION TAdvDataLabel : public TAdvCustomDataLabel
{
	typedef TAdvCustomDataLabel inherited;
	
private:
	System::UnicodeString FCaption;
	System::UnicodeString FData;
	System::UnicodeString FDataFormat;
	int FDataAsInt;
	double FDataAsFloat;
	System::TDateTime FDataAsDateTime;
	TDataType FDataType;
	System::UnicodeString FDataFloatFormat;
	System::UnicodeString FDataDateFormat;
	System::UnicodeString FDataIntFormat;
	bool FSelected;
	Controls::TCursor FOldCursor;
	Classes::TNotifyEvent FOnAnchorClick;
	System::UnicodeString FDataHint;
	bool FDataURL;
	bool FInData;
	void __fastcall SetCaption(const System::UnicodeString Value);
	void __fastcall SetData(const System::UnicodeString Value);
	void __fastcall SetDataAsDate(const System::TDateTime Value);
	void __fastcall SetDataAsDateTime(const System::TDateTime Value);
	void __fastcall SetDataAsFloat(const double Value);
	void __fastcall SetDataAsInt(const int Value);
	void __fastcall SetDataAsTime(const System::TDateTime Value);
	void __fastcall SetDataFormat(const System::UnicodeString Value);
	void __fastcall SetDataDateFormat(const System::UnicodeString Value);
	void __fastcall SetDataFloatFormat(const System::UnicodeString Value);
	void __fastcall SetDataIntFormat(const System::UnicodeString Value);
	void __fastcall SetSelected(const bool Value);
	void __fastcall SetDataURL(const bool Value);
	HIDESBASE MESSAGE void __fastcall CMHintShow(Messages::TMessage &Msg);
	
protected:
	DYNAMIC void __fastcall DblClick(void);
	DYNAMIC void __fastcall Click(void);
	virtual void __fastcall Paint(void);
	virtual void __fastcall Loaded(void);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	Types::TRect __fastcall GetDataRect(void);
	virtual System::UnicodeString __fastcall GetDataString(void);
	virtual System::UnicodeString __fastcall GetCaptionString(void);
	virtual void __fastcall DoAnchorClick(void);
	
public:
	__fastcall virtual TAdvDataLabel(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvDataLabel(void);
	__property int DataAsInt = {read=FDataAsInt, write=SetDataAsInt, nodefault};
	__property double DataAsFloat = {read=FDataAsFloat, write=SetDataAsFloat};
	__property System::TDateTime DataAsDate = {read=FDataAsDateTime, write=SetDataAsDate};
	__property System::TDateTime DataAsTime = {read=FDataAsDateTime, write=SetDataAsTime};
	__property System::TDateTime DataAsDateTime = {read=FDataAsDateTime, write=SetDataAsDateTime};
	__property bool Selected = {read=FSelected, write=SetSelected, nodefault};
	
__published:
	__property Align = {default=0};
	__property Anchors = {default=3};
	__property Constraints;
	__property System::UnicodeString Caption = {read=FCaption, write=SetCaption};
	__property CaptionAlignment = {default=0};
	__property CaptionEllipsis = {default=0};
	__property System::UnicodeString Data = {read=FData, write=SetData};
	__property Font;
	__property DataAlignment = {default=0};
	__property DataEllipsis = {default=0};
	__property DataFont;
	__property System::UnicodeString DataFormat = {read=FDataFormat, write=SetDataFormat};
	__property DataIndent = {default=60};
	__property System::UnicodeString DataIntFormat = {read=FDataIntFormat, write=SetDataIntFormat};
	__property System::UnicodeString DataFloatFormat = {read=FDataFloatFormat, write=SetDataFloatFormat};
	__property System::UnicodeString DataDateFormat = {read=FDataDateFormat, write=SetDataDateFormat};
	__property System::UnicodeString DataHint = {read=FDataHint, write=FDataHint};
	__property bool DataURL = {read=FDataURL, write=SetDataURL, default=0};
	__property DragCursor = {default=-12};
	__property DragKind = {default=0};
	__property DragMode = {default=0};
	__property Enabled = {default=1};
	__property PopupMenu;
	__property ShowHint;
	__property URLColor = {default=16711680};
	__property URLUnderline = {default=1};
	__property Version;
	__property Classes::TNotifyEvent OnAnchorClick = {read=FOnAnchorClick, write=FOnAnchorClick};
	__property OnClick;
	__property OnContextPopup;
	__property OnDblClick;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnEndDock;
	__property OnEndDrag;
	__property Touch;
	__property OnGesture;
	__property OnMouseDown;
	__property OnMouseActivate;
	__property OnMouseEnter;
	__property OnMouseLeave;
	__property OnMouseMove;
	__property OnMouseUp;
	__property OnStartDock;
	__property OnStartDrag;
};


class DELPHICLASS TDataItem;
class PASCALIMPLEMENTATION TDataItem : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	System::UnicodeString FCaption;
	System::UnicodeString FData;
	System::UnicodeString FDataFormat;
	int FDataAsInt;
	double FDataAsFloat;
	System::TDateTime FDataAsDateTime;
	TDataType FDataType;
	System::UnicodeString FDataFloatFormat;
	System::UnicodeString FDataDateFormat;
	System::UnicodeString FDataIntFormat;
	System::UnicodeString FDataHint;
	bool FDataURL;
	Graphics::TFont* FDataFont;
	TEllipsis FDataEllipsis;
	Classes::TAlignment FDataAlignment;
	void __fastcall SetCaption(const System::UnicodeString Value);
	void __fastcall SetData(const System::UnicodeString Value);
	void __fastcall SetDataAsDate(const System::TDateTime Value);
	void __fastcall SetDataAsDateTime(const System::TDateTime Value);
	void __fastcall SetDataAsFloat(const double Value);
	void __fastcall SetDataAsInt(const int Value);
	void __fastcall SetDataAsTime(const System::TDateTime Value);
	void __fastcall SetDataDateFormat(const System::UnicodeString Value);
	void __fastcall SetDataFloatFormat(const System::UnicodeString Value);
	void __fastcall SetDataFormat(const System::UnicodeString Value);
	void __fastcall SetDataIntFormat(const System::UnicodeString Value);
	void __fastcall SetDataURL(const bool Value);
	void __fastcall SetDataFont(const Graphics::TFont* Value);
	void __fastcall SetDataEllipsis(const TEllipsis Value);
	void __fastcall SetDataAlignment(const Classes::TAlignment Value);
	
public:
	__fastcall virtual TDataItem(Classes::TCollection* Collection);
	__fastcall virtual ~TDataItem(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall Changed(void);
	System::UnicodeString __fastcall GetCaptionString(void);
	System::UnicodeString __fastcall GetDataString(void);
	__property int DataAsInt = {read=FDataAsInt, write=SetDataAsInt, nodefault};
	__property double DataAsFloat = {read=FDataAsFloat, write=SetDataAsFloat};
	__property System::TDateTime DataAsDate = {read=FDataAsDateTime, write=SetDataAsDate};
	__property System::TDateTime DataAsTime = {read=FDataAsDateTime, write=SetDataAsTime};
	__property System::TDateTime DataAsDateTime = {read=FDataAsDateTime, write=SetDataAsDateTime};
	
__published:
	__property System::UnicodeString Caption = {read=FCaption, write=SetCaption};
	__property System::UnicodeString Data = {read=FData, write=SetData};
	__property Classes::TAlignment DataAlignment = {read=FDataAlignment, write=SetDataAlignment, default=0};
	__property TEllipsis DataEllipsis = {read=FDataEllipsis, write=SetDataEllipsis, default=0};
	__property Graphics::TFont* DataFont = {read=FDataFont, write=SetDataFont};
	__property System::UnicodeString DataFormat = {read=FDataFormat, write=SetDataFormat};
	__property System::UnicodeString DataIntFormat = {read=FDataIntFormat, write=SetDataIntFormat};
	__property System::UnicodeString DataFloatFormat = {read=FDataFloatFormat, write=SetDataFloatFormat};
	__property System::UnicodeString DataDateFormat = {read=FDataDateFormat, write=SetDataDateFormat};
	__property System::UnicodeString DataHint = {read=FDataHint, write=FDataHint};
	__property bool DataURL = {read=FDataURL, write=SetDataURL, default=0};
};


class DELPHICLASS TDataCollection;
class DELPHICLASS TAdvDataList;
class PASCALIMPLEMENTATION TDataCollection : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
public:
	TDataItem* operator[](int Index) { return Items[Index]; }
	
private:
	TAdvDataList* FList;
	HIDESBASE TDataItem* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, const TDataItem* Value);
	
protected:
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	
public:
	__fastcall TDataCollection(TAdvDataList* AOwner);
	HIDESBASE TDataItem* __fastcall Add(void);
	HIDESBASE TDataItem* __fastcall Insert(int Index);
	__property TDataItem* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TDataCollection(void) { }
	
};


typedef void __fastcall (__closure *TAnchorEvent)(System::TObject* Sender, int Index);

class PASCALIMPLEMENTATION TAdvDataList : public TAdvCustomDataLabel
{
	typedef TAdvCustomDataLabel inherited;
	
private:
	TDataCollection* FData;
	int FHintItem;
	Controls::TCursor FOldCursor;
	TAnchorEvent FOnAnchorClick;
	void __fastcall SetData(const TDataCollection* Value);
	
protected:
	virtual void __fastcall Paint(void);
	virtual void __fastcall Loaded(void);
	HIDESBASE MESSAGE void __fastcall CMHintShow(Messages::TMessage &Msg);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	virtual void __fastcall DoAnchorClick(int Index);
	
public:
	__fastcall virtual TAdvDataList(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvDataList(void);
	int __fastcall XYToItem(int X, int Y);
	Types::TRect __fastcall GetItemRect(int Index);
	Types::TRect __fastcall GetDataRect(int Index);
	
__published:
	__property Align = {default=0};
	__property Anchors = {default=3};
	__property Constraints;
	__property CaptionAlignment = {default=0};
	__property CaptionEllipsis = {default=0};
	__property TDataCollection* Data = {read=FData, write=SetData};
	__property DataFont;
	__property DataIndent = {default=60};
	__property DragCursor = {default=-12};
	__property DragKind = {default=0};
	__property DragMode = {default=0};
	__property Enabled = {default=1};
	__property Font;
	__property PopupMenu;
	__property Separator;
	__property ShowHint;
	__property Version;
	__property TAnchorEvent OnAnchorClick = {read=FOnAnchorClick, write=FOnAnchorClick};
	__property OnClick;
	__property OnContextPopup;
	__property OnDblClick;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnEndDock;
	__property OnEndDrag;
	__property OnGesture;
	__property Touch;
	__property OnMouseDown;
	__property OnMouseActivate;
	__property OnMouseEnter;
	__property OnMouseLeave;
	__property OnMouseMove;
	__property OnMouseUp;
	__property OnStartDock;
	__property OnStartDrag;
};


//-- var, const, procedure ---------------------------------------------------
static const System::ShortInt MAJ_VER = 0x1;
static const System::ShortInt MIN_VER = 0x0;
static const System::ShortInt REL_VER = 0x0;
static const System::ShortInt BLD_VER = 0x0;

}	/* namespace Advdatalabel */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advdatalabel;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvdatalabelHPP
