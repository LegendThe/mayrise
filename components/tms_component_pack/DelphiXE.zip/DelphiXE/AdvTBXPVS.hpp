// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvTBXPVS.pas' rev: 22.00

#ifndef AdvtbxpvsHPP
#define AdvtbxpvsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

#include "uxtheme.h"


namespace Advtbxpvs
{
//-- type declarations -------------------------------------------------------
typedef _MARGINS TMargins;

//-- var, const, procedure ---------------------------------------------------
static const System::Word TMT_CAPTIONFONT = 0x321;
extern PACKAGE bool __fastcall UseThemes(void);

}	/* namespace Advtbxpvs */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advtbxpvs;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvtbxpvsHPP
