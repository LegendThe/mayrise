// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvLockApp.pas' rev: 22.00

#ifndef AdvlockappHPP
#define AdvlockappHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advlockapp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TLockDialog;
class PASCALIMPLEMENTATION TLockDialog : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FLabelPassword;
	System::UnicodeString FLabelUserName;
	System::UnicodeString FCaption;
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__fastcall TLockDialog(void);
	
__published:
	__property System::UnicodeString Caption = {read=FCaption, write=FCaption};
	__property System::UnicodeString LabelUsername = {read=FLabelUserName, write=FLabelUserName};
	__property System::UnicodeString LabelPassword = {read=FLabelPassword, write=FLabelPassword};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TLockDialog(void) { }
	
};


typedef void __fastcall (__closure *TVerifyPasswordEvent)(System::TObject* Sender, System::UnicodeString Password, bool &Valid);

typedef void __fastcall (__closure *TQueryUnlockEvent)(System::TObject* Sender, bool &AllowUnlock);

class DELPHICLASS TAdvLockApp;
class PASCALIMPLEMENTATION TAdvLockApp : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	bool FLocked;
	Graphics::TIcon* FLockedIcon;
	Graphics::TIcon* FUnLockedIcon;
	System::UnicodeString FPassword;
	System::UnicodeString FUserName;
	bool FEnabled;
	int FSeconds;
	Forms::TIdleEvent FOnIdle;
	Forms::TForm* FActiveForm;
	Forms::TForm* FModalActiveForm;
	Extctrls::TTimer* Ftimer;
	bool FIncorrectPW;
	bool FIsWin7;
	Classes::TWndMethod FFormWndProc;
	Classes::TWndMethod FModalFormWndProc;
	Forms::TIdleEvent FAppIdle;
	Forms::TMessageEvent FAppMessage;
	Classes::TNotifyEvent FOnLock;
	Classes::TNotifyEvent FOnUnLock;
	TLockDialog* FDialog;
	TVerifyPasswordEvent FOnVerifyPassword;
	Classes::TNotifyEvent FOnIncorrectPassword;
	System::UnicodeString FIncorrectPassword;
	TQueryUnlockEvent FOnQueryUnlock;
	bool FActivatingHack;
	bool FIsWinXP;
	bool FIsD2k7Lvl;
	void __fastcall DoIdle(System::TObject* Sender, bool &Done);
	void __fastcall DoMessage(tagMSG &Msg, bool &Handled);
	void __fastcall UnlockPWDlg(void);
	void __fastcall DoLockUnlock(void);
	void __fastcall SetLockedIcon(Graphics::TIcon* Value);
	void __fastcall SetUnLockedIcon(Graphics::TIcon* Value);
	void __fastcall SetMinutes(int Value);
	int __fastcall GetMinutes(void);
	void __fastcall SetEnabled(bool Value);
	void __fastcall OnTimer(System::TObject* Sender);
	System::UnicodeString __fastcall GetVersion(void);
	void __fastcall SetVersion(const System::UnicodeString Value);
	void __fastcall SetActiveForm(void);
	void __fastcall SetSeconds(const int Value);
	void __fastcall SetDialog(const TLockDialog* Value);
	
protected:
	bool __fastcall HookProc(Messages::TMessage &Message);
	void __fastcall SubClassProc(Messages::TMessage &Message);
	void __fastcall ModalSubClassProc(Messages::TMessage &Message);
	virtual void __fastcall Loaded(void);
	virtual bool __fastcall DoVerifyPassword(System::UnicodeString Password, bool &Valid);
	virtual void __fastcall DoIncorrectPassword(void);
	virtual bool __fastcall DoQueryUnlock(void);
	HBITMAP __fastcall GetPreviewBtimap(int Height, int Width);
	virtual HRESULT __fastcall DoSetIconicThumbnail(unsigned Wnd, int Width, int Height);
	
public:
	__fastcall virtual TAdvLockApp(Classes::TComponent* AOwner);
	__fastcall virtual ~TAdvLockApp(void);
	virtual int __fastcall GetVersionNr(void);
	void __fastcall Lock(void);
	
__published:
	__property TLockDialog* Dialog = {read=FDialog, write=SetDialog};
	__property System::UnicodeString Password = {read=FPassword, write=FPassword};
	__property System::UnicodeString UserName = {read=FUserName, write=FUserName};
	__property Graphics::TIcon* LockedIcon = {read=FLockedIcon, write=SetLockedIcon};
	__property Graphics::TIcon* UnLockedIcon = {read=FUnLockedIcon, write=SetUnLockedIcon};
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=0};
	__property int IdleMinutes = {read=GetMinutes, write=SetMinutes, default=0};
	__property int IdleSeconds = {read=FSeconds, write=SetSeconds, default=10};
	__property System::UnicodeString IncorrectPassword = {read=FIncorrectPassword, write=FIncorrectPassword};
	__property System::UnicodeString Version = {read=GetVersion, write=SetVersion};
	__property Forms::TIdleEvent OnIdle = {read=FOnIdle, write=FOnIdle};
	__property TQueryUnlockEvent OnQueryUnlock = {read=FOnQueryUnlock, write=FOnQueryUnlock};
	__property Classes::TNotifyEvent OnLock = {read=FOnLock, write=FOnLock};
	__property Classes::TNotifyEvent OnUnLock = {read=FOnUnLock, write=FOnUnLock};
	__property TVerifyPasswordEvent OnVerifyPassword = {read=FOnVerifyPassword, write=FOnVerifyPassword};
	__property Classes::TNotifyEvent OnIncorrectPassword = {read=FOnIncorrectPassword, write=FOnIncorrectPassword};
};


//-- var, const, procedure ---------------------------------------------------
static const System::ShortInt MAJ_VER = 0x1;
static const System::ShortInt MIN_VER = 0x0;
static const System::ShortInt REL_VER = 0x0;
static const System::ShortInt BLD_VER = 0x6;

}	/* namespace Advlockapp */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advlockapp;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvlockappHPP
