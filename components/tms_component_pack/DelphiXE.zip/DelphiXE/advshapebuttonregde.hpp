// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvShapeButtonRegDE.pas' rev: 22.00

#ifndef AdvshapebuttonregdeHPP
#define AdvshapebuttonregdeHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <AdvShapeButton.hpp>	// Pascal unit
#include <AdvShapeButtonDE.hpp>	// Pascal unit
#include <GDIPicDE.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <GDIPicture.hpp>	// Pascal unit
#include <AdvHintInfo.hpp>	// Pascal unit
#include <DesignIntf.hpp>	// Pascal unit
#include <DesignEditors.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advshapebuttonregde
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Advshapebuttonregde */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advshapebuttonregde;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvshapebuttonregdeHPP
