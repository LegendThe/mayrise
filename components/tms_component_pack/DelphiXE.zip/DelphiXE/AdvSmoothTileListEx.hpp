// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvSmoothTileListEx.pas' rev: 22.00

#ifndef AdvsmoothtilelistexHPP
#define AdvsmoothtilelistexHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <AdvSmoothTileList.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advsmoothtilelistex
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TAdvSmoothTileContentEx;
class PASCALIMPLEMENTATION TAdvSmoothTileContentEx : public Advsmoothtilelist::TAdvSmoothTileContent
{
	typedef Advsmoothtilelist::TAdvSmoothTileContent inherited;
	
private:
	System::UnicodeString FExtra;
	
__published:
	__property System::UnicodeString Extra = {read=FExtra, write=FExtra};
public:
	/* TAdvSmoothTileContent.Create */ inline __fastcall TAdvSmoothTileContentEx(Advsmoothtilelist::TAdvSmoothTile* AOwner) : Advsmoothtilelist::TAdvSmoothTileContent(AOwner) { }
	/* TAdvSmoothTileContent.Destroy */ inline __fastcall virtual ~TAdvSmoothTileContentEx(void) { }
	
};


class DELPHICLASS TAdvSmoothTileEx;
class PASCALIMPLEMENTATION TAdvSmoothTileEx : public Advsmoothtilelist::TAdvSmoothTile
{
	typedef Advsmoothtilelist::TAdvSmoothTile inherited;
	
private:
	System::UnicodeString FExtra;
	
public:
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual Advsmoothtilelist::TAdvSmoothTileContent* __fastcall CreateContent(void);
	virtual Advsmoothtilelist::TAdvSmoothTileContent* __fastcall CreateContentMaximized(void);
	
__published:
	__property System::UnicodeString Extra = {read=FExtra, write=FExtra};
public:
	/* TAdvSmoothTile.Create */ inline __fastcall virtual TAdvSmoothTileEx(Classes::TCollection* Collection) : Advsmoothtilelist::TAdvSmoothTile(Collection) { }
	/* TAdvSmoothTile.Destroy */ inline __fastcall virtual ~TAdvSmoothTileEx(void) { }
	
};


class DELPHICLASS TAdvSmoothTilesEx;
class PASCALIMPLEMENTATION TAdvSmoothTilesEx : public Advsmoothtilelist::TAdvSmoothTiles
{
	typedef Advsmoothtilelist::TAdvSmoothTiles inherited;
	
public:
	virtual Classes::TCollectionItemClass __fastcall CreateItemClass(void);
public:
	/* TAdvSmoothTiles.Create */ inline __fastcall TAdvSmoothTilesEx(Advsmoothtilelist::TAdvSmoothTileList* AOwner) : Advsmoothtilelist::TAdvSmoothTiles(AOwner) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TAdvSmoothTilesEx(void) { }
	
};


class DELPHICLASS TAdvSmoothTileListEx;
class PASCALIMPLEMENTATION TAdvSmoothTileListEx : public Advsmoothtilelist::TAdvSmoothTileList
{
	typedef Advsmoothtilelist::TAdvSmoothTileList inherited;
	
public:
	virtual Advsmoothtilelist::TAdvSmoothTiles* __fastcall CreateTiles(void);
public:
	/* TAdvSmoothTileList.Create */ inline __fastcall virtual TAdvSmoothTileListEx(Classes::TComponent* AOwner) : Advsmoothtilelist::TAdvSmoothTileList(AOwner) { }
	/* TAdvSmoothTileList.Destroy */ inline __fastcall virtual ~TAdvSmoothTileListEx(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TAdvSmoothTileListEx(HWND ParentWindow) : Advsmoothtilelist::TAdvSmoothTileList(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Advsmoothtilelistex */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advsmoothtilelistex;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvsmoothtilelistexHPP
