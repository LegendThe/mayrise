// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvSmoothTileListHTMLVisualizer.pas' rev: 22.00

#ifndef AdvsmoothtilelisthtmlvisualizerHPP
#define AdvsmoothtilelisthtmlvisualizerHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <AdvGDIP.hpp>	// Pascal unit
#include <AdvSmoothTileList.hpp>	// Pascal unit
#include <AdvSmoothTileListImageVisualizer.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advsmoothtilelisthtmlvisualizer
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TAdvSmoothTileListHTMLVisualizer;
class PASCALIMPLEMENTATION TAdvSmoothTileListHTMLVisualizer : public Advsmoothtilelistimagevisualizer::TAdvSmoothTileListImageVisualizer
{
	typedef Advsmoothtilelistimagevisualizer::TAdvSmoothTileListImageVisualizer inherited;
	
private:
	System::UnicodeString preva;
	
public:
	System::UnicodeString __fastcall XYToAnchor(Advsmoothtilelist::TAdvSmoothTile* Tile, int pX, int pY);
	virtual bool __fastcall DoMouseDown(Advsmoothtilelist::TAdvSmoothTile* Tile, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	virtual bool __fastcall DoMouseMove(Advsmoothtilelist::TAdvSmoothTile* Tile, Classes::TShiftState Shift, int X, int Y);
	virtual bool __fastcall DoMouseUp(Advsmoothtilelist::TAdvSmoothTile* Tile, Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	virtual Advgdip::TGPRectF __fastcall DrawText(Advgdip::TGPGraphics* g, const Advgdip::TGPRectF &R, Advsmoothtilelist::TAdvSmoothTile* Tile, System::UnicodeString Text);
public:
	/* TAdvSmoothTileListVisualizer.Create */ inline __fastcall virtual TAdvSmoothTileListHTMLVisualizer(Classes::TComponent* AOwner) : Advsmoothtilelistimagevisualizer::TAdvSmoothTileListImageVisualizer(AOwner) { }
	
public:
	/* TComponent.Destroy */ inline __fastcall virtual ~TAdvSmoothTileListHTMLVisualizer(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Advsmoothtilelisthtmlvisualizer */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advsmoothtilelisthtmlvisualizer;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvsmoothtilelisthtmlvisualizerHPP
