// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvHorizontalPolyList.pas' rev: 22.00

#ifndef AdvhorizontalpolylistHPP
#define AdvhorizontalpolylistHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <CustomItemsContainer.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <GDIPBase.hpp>	// Pascal unit
#include <GDIPFill.hpp>	// Pascal unit
#include <GDIPPictureContainer.hpp>	// Pascal unit
#include <ImgList.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <GDIPCustomItem.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <AdvGDIP.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advhorizontalpolylist
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TAdvHorizontalPolyList;
class PASCALIMPLEMENTATION TAdvHorizontalPolyList : public Customitemscontainer::TCustomItemsContainer
{
	typedef Customitemscontainer::TCustomItemsContainer inherited;
	
public:
	__fastcall virtual TAdvHorizontalPolyList(Classes::TComponent* AOwner);
	
__published:
	__property AutoSizeMode = {default=1};
	__property AutoSizeType = {default=0};
	__property List;
	__property Fill;
	__property HorizontalSpacing = {default=5};
	__property VerticalSpacing = {default=5};
	__property ListMargins;
	__property ReadOnly = {default=0};
	__property Reorder = {default=1};
	__property ShowFocus = {default=1};
	__property BorderMode = {default=0};
	__property BorderTypes = {default=15};
	__property PictureContainer;
	__property ImageList;
	__property Version;
	__property DragLine = {default=1};
	__property DragLineColor = {default=255};
	__property OnStartDraw;
	__property OnEndDraw;
	__property OnChange;
	__property OnItemCompare;
	__property OnItemSelect;
	__property OnItemDeSelect;
	__property OnItemAppearance;
	__property Align = {default=0};
	__property Anchors = {default=3};
	__property Ctl3D;
	__property BorderStyle = {default=0};
	__property Constraints;
	__property PopupMenu;
	__property TabOrder = {default=-1};
	__property ParentShowHint = {default=1};
	__property ShowHint;
	__property OnKeyDown;
	__property OnKeyPress;
	__property OnKeyUp;
	__property OnMouseUp;
	__property OnMouseMove;
	__property OnMouseDown;
	__property OnMouseEnter;
	__property OnMouseLeave;
	__property DragKind = {default=0};
	__property DragMode = {default=0};
	__property OnResize;
	__property OnDblClick;
	__property OnClick;
	__property OnEnter;
	__property OnExit;
	__property OnStartDrag;
	__property OnEndDrag;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnItemReorder;
	__property Visible = {default=1};
	__property TabStop = {default=1};
	__property OnGesture;
	__property Touch;
	__property HandleAppearance;
	__property ScrollType = {default=0};
	__property ThumbTracking = {default=1};
	__property BevelEdges = {default=15};
	__property BevelInner = {index=0, default=2};
	__property BevelOuter = {index=1, default=1};
	__property BevelKind = {default=0};
	__property BevelWidth = {default=1};
	__property BiDiMode;
	__property DockSite = {default=0};
	__property DoubleBuffered;
	__property DragCursor = {default=-12};
	__property Enabled = {default=1};
	__property Color;
	__property Padding;
	__property ParentBackground = {default=0};
	__property ParentBiDiMode = {default=1};
	__property ParentCtl3D = {default=1};
	__property ParentFont = {default=1};
	__property OnCanResize;
	__property OnConstrainedResize;
	__property OnContextPopup;
	__property OnDockDrop;
	__property OnDockOver;
	__property OnEndDock;
	__property OnGetSiteInfo;
	__property OnMouseWheel;
	__property OnMouseWheelDown;
	__property OnMouseWheelUp;
	__property OnStartDock;
	__property OnUnDock;
	__property Transparent = {default=0};
	__property TextRendering = {default=5};
	__property OnVerticalScroll;
	__property OnHorizontalScroll;
public:
	/* TCustomItemsContainer.Destroy */ inline __fastcall virtual ~TAdvHorizontalPolyList(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TAdvHorizontalPolyList(HWND ParentWindow) : Customitemscontainer::TCustomItemsContainer(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Advhorizontalpolylist */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advhorizontalpolylist;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvhorizontalpolylistHPP
