// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvMetroDlgs.pas' rev: 22.00

#ifndef AdvmetrodlgsHPP
#define AdvmetrodlgsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <AdvMetroForm.hpp>	// Pascal unit
#include <AdvStyleIF.hpp>	// Pascal unit
#include <HTMLabel.hpp>	// Pascal unit
#include <AdvMetroRes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advmetrodlgs
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall MetroShowMessage(System::UnicodeString Text)/* overload */;
extern PACKAGE void __fastcall MetroShowMessage(System::UnicodeString Text, System::UnicodeString Caption)/* overload */;
extern PACKAGE void __fastcall MetroShowMessage(System::UnicodeString Text, System::UnicodeString Caption, System::UnicodeString CaptionText)/* overload */;
extern PACKAGE int __fastcall MetroMessageBox(HWND hWnd, System::WideChar * lpInstruction, System::WideChar * lpTitle, unsigned flags);
extern PACKAGE void __fastcall MetroShowMessageFmt(const System::UnicodeString Instruction, System::TVarRec *Parameters, const int Parameters_Size);
extern PACKAGE int __fastcall MetroMessageDlg(const System::UnicodeString Instruction, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, int HelpCtx)/* overload */;
extern PACKAGE int __fastcall MetroMessageDlg(const System::UnicodeString Instruction, Dialogs::TMsgDlgType DlgType, Dialogs::TMsgDlgButtons Buttons, int HelpCtx, Dialogs::TMsgDlgBtn DefaultButton)/* overload */;
extern PACKAGE bool __fastcall MetroInputQueryDlg(System::UnicodeString ACaption, System::UnicodeString APrompt, System::UnicodeString &Value);

}	/* namespace Advmetrodlgs */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advmetrodlgs;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvmetrodlgsHPP
