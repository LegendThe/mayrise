// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvMemoReg.pas' rev: 22.00

#ifndef AdvmemoregHPP
#define AdvmemoregHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <AdvMemo.hpp>	// Pascal unit
#include <AdvmCSS.hpp>	// Pascal unit
#include <AdvmPS.hpp>	// Pascal unit
#include <AdvmBS.hpp>	// Pascal unit
#include <AdvmWS.hpp>	// Pascal unit
#include <AdvmSQLS.hpp>	// Pascal unit
#include <AdvmCSHS.hpp>	// Pascal unit
#include <AdvmPYS.hpp>	// Pascal unit
#include <AdvmPLS.hpp>	// Pascal unit
#include <AdvmES.hpp>	// Pascal unit
#include <AdvmINIs.hpp>	// Pascal unit
#include <Advmxml.hpp>	// Pascal unit
#include <advmphp.hpp>	// Pascal unit
#include <AdvCodeList.hpp>	// Pascal unit
#include <AdvMemoStylerManager.hpp>	// Pascal unit
#include <DBAdvMemo.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advmemoreg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Advmemoreg */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advmemoreg;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvmemoregHPP
