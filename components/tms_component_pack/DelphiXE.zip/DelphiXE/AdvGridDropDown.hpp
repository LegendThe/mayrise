// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvGridDropDown.pas' rev: 22.00

#ifndef AdvgriddropdownHPP
#define AdvgriddropdownHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <AdvCustomGridDropDown.hpp>	// Pascal unit
#include <AdvGrid.hpp>	// Pascal unit
#include <AdvDropDown.hpp>	// Pascal unit
#include <Mask.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advgriddropdown
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TAdvGridDropDown;
class PASCALIMPLEMENTATION TAdvGridDropDown : public Advcustomgriddropdown::TCustomAdvGridDropDown
{
	typedef Advcustomgriddropdown::TCustomAdvGridDropDown inherited;
	
private:
	Advgrid::TAdvStringGrid* __fastcall GetAdvGrid(void);
	
public:
	__property Advgrid::TAdvStringGrid* Grid = {read=GetAdvGrid};
public:
	/* TCustomAdvGridDropDown.Create */ inline __fastcall virtual TAdvGridDropDown(Classes::TComponent* AOwner) : Advcustomgriddropdown::TCustomAdvGridDropDown(AOwner) { }
	/* TCustomAdvGridDropDown.Destroy */ inline __fastcall virtual ~TAdvGridDropDown(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TAdvGridDropDown(HWND ParentWindow) : Advcustomgriddropdown::TCustomAdvGridDropDown(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Advgriddropdown */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advgriddropdown;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvgriddropdownHPP
