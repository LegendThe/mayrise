// CodeGear C++Builder
// Copyright (c) 1995, 2010 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'AdvCardListGradient.pas' rev: 22.00

#ifndef AdvcardlistgradientHPP
#define AdvcardlistgradientHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Buttons.hpp>	// Pascal unit
#include <StdCtrls.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <AdvCardList.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Advcardlistgradient
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TGradientEditor;
class PASCALIMPLEMENTATION TGradientEditor : public Forms::TForm
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPaintBox* PaintBox1;
	Extctrls::TRadioGroup* RadioGroup1;
	Stdctrls::TButton* Button1;
	Stdctrls::TButton* Button2;
	Buttons::TSpeedButton* SpeedButton1;
	Buttons::TSpeedButton* SpeedButton2;
	Dialogs::TColorDialog* ColorDialog1;
	void __fastcall PaintBox1Paint(System::TObject* Sender);
	void __fastcall SpeedButton1Click(System::TObject* Sender);
	void __fastcall SpeedButton2Click(System::TObject* Sender);
	void __fastcall RadioGroup1Click(System::TObject* Sender);
	
private:
	Advcardlist::TAdvGradient* FColor;
	Graphics::TColor FOldColorTo;
	HIDESBASE void __fastcall SetColor(const Advcardlist::TAdvGradient* Value);
	
public:
	__fastcall virtual TGradientEditor(Classes::TComponent* Aowner);
	__fastcall virtual ~TGradientEditor(void);
	__property Advcardlist::TAdvGradient* Color = {read=FColor, write=SetColor};
public:
	/* TCustomForm.CreateNew */ inline __fastcall virtual TGradientEditor(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TGradientEditor(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TGradientEditor* GradientEditor;

}	/* namespace Advcardlistgradient */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE)
using namespace Advcardlistgradient;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// AdvcardlistgradientHPP
