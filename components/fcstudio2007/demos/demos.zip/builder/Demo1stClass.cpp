//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//---------------------------------------------------------------------------
USEFORM("ButtonGroup\About.cpp", AboutBox);
USEFORM("ButtonGroup\buttongroupdemo.cpp", ButtonGroupDemoForm);
USEFORM("ButtonGroup\childwin.cpp", MDIChild);
USEFORM("ButtonGroup\mainmdi.cpp", MainMdiForm);
USEFORM("ButtonGroup\tabbuttons.cpp", TabBtnGroupForm);
USEFORM("MainU.cpp", MainForm);
USEFORM("OutlookBar\infounit.cpp", InfoForm);
USEFORM("OutlookBar\outlookbaru.cpp", OutlookBarForm);
USEFORM("OutlookBar\paintu.cpp", PaintForm);
USEFORM("ImageForm\imagetabformu.cpp", ImageTabForm);
USEFORM("ImageForm\orderformu.cpp", OrderForm);
USEFORM("imager\ImagerMain.cpp", ImagerForm);
USEFORM("imager\PicEdt.cpp", fcPicEditor);
USEFORM("imager\TilerUnit.cpp", TilerDemoForm);
USEFORM("ColorDemo\colordemou.cpp", ColorDemoForm);
USEFORM("treeview\TreeDemo.cpp", TreeViewDemoForm);
USEFORM("Buttons\imagebuttonu.cpp", ImageBtnDemoForm);
USEFORM("Buttons\mapu.cpp", MapForm);
USEFORM("Buttons\shapeu.cpp", ShapeBtnDemoForm);
USEFORM("dbtreeview\DBTreeSample.cpp", DMTreeViewForm);
USEFORM("Labels\labelu.cpp", LabelForm);
USEFORM("StatusBar\proportionalu.cpp", ProportionalStatusBarForm);
USEFORM("StatusBar\statusbaru.cpp", StatusBarDemoForm);
USEFORM("framing\FrameU.cpp", FrameDemoForm);
USEFORM("TreeCombos\TreeCombos.cpp", TreeComboDemoForm);
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->CreateForm(__classid(TMainForm), &MainForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
